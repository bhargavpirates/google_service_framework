from setuptools import setup

setup(
    name="Google Services Pipeline Builder",
    version="1.0",
    description="----",
    author="Bhargav Geddam",
    author_email="bgeddam@micron.com",
    package_dir={"": "./src"},
    install_requires=[
        'pyspark',
        'google-cloud-storage',
        'google-cloud-bigquery',
        'google-cloud-dataproc',
        'google-cloud-logging',
    ],
    licence='MICRON',
    packages=["GPBR"],
)