"""
This module helps to create,delete and modify BigQuery resources like datasets,tables
"""

#from google.cloud import bigquery
import traceback
import sys
from google.cloud import bigquery
from google.cloud.exceptions import NotFound

class DDL:
    """
    DDL Methods for BigQuery client.

    Args:
        project_id (str): ID corresponding to the project in which the DDL operations take place.


    Examples:
        >>> obj = DDL("gdw-dev-smai-vtctrimopt")
    """

    def __init__(self, project_id, env=""):
        if(env.lower()=='local'):
            #adc_file_path = cfg["adc_file_path"]  # /home/jupyter/.config/gcloud/application_default_credentials.json
            adc_file_path = 'C:\\Users\\bgeddam\\AppData\\Roaming\\gcloud\\application_default_credentials.json'
            os.environ["GOOGLE_CLOUD_PROJECT"] = project_id
            os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = adc_file_path
            source_credentials, project = google.auth.default()
            service_account = f'shared-service-account@{project_id}.iam.gserviceaccount.com'
            target_scopes = ['https://www.googleapis.com/auth/cloud-platform']
            target_credentials = impersonated_credentials.Credentials(source_credentials=source_credentials,
                                                                  target_principal=service_account,
                                                                  target_scopes=target_scopes, lifetime=3600)
            self.project = project_id
            self.client = bigquery.Client(project=self.project, credentials=target_credentials)
        else:
            self.project = project_id #: : (str) ID corresponding to the project in which the DDL operations take place.
            self.client = bigquery.Client(self.project) #: : (google.cloud.bigquery.client.Client) Client object used to make API requests.


    def create_dataset(self,dataset_name):
        """
        Create a dataset with given name in the current project.

        Args:
            dataset_name (str): Name of the dataset to be created.

        Example:
            >>> obj.create_dataset('dummy_demo_dataset')
            Created dataset gdw-dev-smai-vtctrimopt.dummy_demo_dataset

        """
        try:
            dataset_id = self.project+"."+dataset_name 
            dataset_ref = bigquery.DatasetReference.from_string(dataset_id, default_project=self.client.project)
            dataset = bigquery.Dataset(dataset_ref)
            dataset.location = "US"
            dataset_list = self.list_datasets()
            if dataset_name in dataset_list:
                print("Dataset {}.{} already exists".format(self.client.project, dataset.dataset_id))
                return 
            dataset = self.client.create_dataset(dataset)
            print("Created dataset {}.{}".format(self.client.project, dataset.dataset_id))
        except:
            traceback.print_exc()
            



    def list_datasets(self):
        """
        List all the datasets in the current project.

        Returns:
            [str]: list of datasets in the project

        Example:
            >>> print(obj.list_datasets())
            [auditing_dataset,dev_audit_dataset,testing_dataset,vtctrim_dev_auditing_dataset,vtctrim_dev_dataset]
        
        """
        try:
            datasets = list(self.client.list_datasets())  # Make an API request.
            project = self.client.project
            dataset_list = []
            if datasets:
                # print("Datasets in project {}:".format(project))
                for dataset in datasets:
                    dataset_list.append(dataset.dataset_id)
                    # print("\t{}".format(dataset.dataset_id))
            else:
                print("{} project does not contain any datasets.".format(project))
            return dataset_list
        except:
            traceback.print_exc()
            

    def update_dataset(self, dataset_name, new_description):    
        """
        Update the Description of the specified Dataset.

        Args:
            dataset_name (str): Name corresponding to the dataset whose description is to be updated.
            new_description (str): Updated description of the dataset.

        Example:
            >>> obj.update_dataset('sample_dataset','a test dataset')
            Updated dataset 'gdw-dev-smai-vtctrimopt.sample_dataset' with description 'a test dataset'.

        """
        try:
            dataset = self.client.get_dataset(dataset_name)
            dataset.description = new_description
            dataset = self.client.update_dataset(dataset, ["description"])

            full_dataset_id = "{}.{}".format(dataset.project, dataset.dataset_id)
            print("Updated dataset '{}' with description '{}'.".format(full_dataset_id, dataset.description))
        except:
            traceback.print_exc()
            

    def delete_dataset(self, dataset_name):
        """Delete the specified Dataset.

        Args:
            dataset_name (str): Name corresponding to the dataset which is to be deleted.

        Example:
            >>> obj.delete_dataset('sample_dataset')
            Deleted dataset 'gdw-dev-smai-vtctrimopt.sample_dataset'.

        """
        try:
            self.client.delete_dataset(dataset_name, delete_contents=True, not_found_ok=True)
            print("Deleted dataset '{}'.".format(dataset_name))
        except:
            traceback.print_exc()
            
            
    def schema_prep(self, schema_lst):
        schema = []
        for i in schema_lst:
            if (len(i) >= 2):
                if (len(i) == 2):
                    schema.append(bigquery.SchemaField(i[0], i[1], mode="NULLABLE"))
                else:
                    schema.append(bigquery.SchemaField(i[0], i[1], mode=i[2]))
            else:
                print("please send correct schema")
        return schema


    def create_table(self, table_id, schema_lst):
        """
        Create a table with specified name and schema.
        
        Args:
            table_id (str): ID for the table to be created.
            schema ([[str,str]]/[[str,str,str]]): Schema for the newly created table.

        Examples:
            >>> obj = DDL("gdw-dev-smai-vtctrimopt")
            >>> table_schema = [["id","INTEGER"],["name","STRING"]]
            >>> obj.create_table("gdw-dev-smai-vtctrimopt.auditing_dataset.testing_bigquery", table_schema)
            Table gdw-dev-smai-vtctrimopt.auditing_dataset.testing_bigquery is not found...so creating it
            Created table gdw-dev-smai-vtctrimopt.auditing_dataset.testing_bigquery

        """
        # table_id = Table.from_string(table_id)
        try:
            self.client.get_table(table_id)  # Make an API request.
            print("Table {} already exists.".format(table_id))
        except NotFound:
            print("Table {} is not found...so creating it".format(table_id))
            schema = self.schema_prep(schema_lst)
            table = bigquery.Table(table_id, schema=schema)
            table = self.client.create_table(table)  # Make an API request.
            print("Created table {}.{}.{}".format(table.project, table.dataset_id, table.table_id))


    # google.api_core.exceptions.NotFound unless not_found_ok is True.
    def delete_table(self, table_id):    
        """
        Delete the specified table.

        Args:
            table_id (str): Valid ID that refers to the table to be deleted.
        
        Examples:
            >>> obj.delete_table("gdw-dev-smai-vtctrimopt.auditing_dataset.testing_bigquery")
            Deleted table 'gdw-dev-smai-vtctrimopt.auditing_dataset.testing_bigquery'.

        """
        try:
            self.client.delete_table(table_id, not_found_ok=True)
            print("Deleted table '{}'.".format(table_id))
        except:
            traceback.print_exc()
            

