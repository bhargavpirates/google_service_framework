"""
Data Manipulation Language (DML) enables you to update, insert, and delete data from your BigQuery tables.
"""

import traceback
import sys
from google.cloud import bigquery
#client = bigquery.Client()

class DML:
    """
    DML Methods for BigQuery client.

    Args:
        project_id (str): ID corresponding to the project in which the DML operations take place.

    Examples:
        >>> dml_obj = DML('my-sample-project')


    """

    def __init__(self, project_id):
        self.project = project_id#: : (str) ID corresponding to the project in which the DML operations take place.
        self.client = bigquery.Client(self.project)#: : (google.cloud.bigquery.client.Client) Client object used to make API requests.


    def insert_rows_from_list(self, dataset_name, table_name, rows_to_insert):
        '''
        Append rows/entries to specified table.

        Args:
            dataset_name (str): The dataset to which the table belongs to.
            table_name (str): The table to which the rows should be inserted.
            rows_to_insert (list(tuple)): The rows to be inserted.

        Examples:
            >>> obj.insert_rows_from_list('auditing_dataset', 'testing_bigquery', [(1,'xyz'),(2,'qrt'),(3,'rrr')])
        '''
        try:
            dataset_ref = self.client.dataset(dataset_name)
            table_ref = dataset_ref.table(table_name)
            table = self.client.get_table(table_ref)  # API call
        
            errors = self.client.insert_rows(table, rows_to_insert)  # API request
            assert errors == []
        except:
            traceback.print_exc()
            



    def query_tables(self, query):
        '''
        Run a SQL query and print the result.

        Args:
            query (str): provide SELECT statement query.

        Returns:
            [google.cloud.bigquery.table.Row]: List of all the rows that matched the query. 

        Examples:
            >>> print(obj.query_tables("select * from auditing_dataset.testing_bigquery where id > 1"))
            [Row((2, 'qrt'), {'id': 0, 'name': 1}), Row((3, 'rrr'), {'id': 0, 'name': 1})]
        '''
        try:
            query_job = self.client.query(query)
            rows = query_job.result()
            return [row for row in rows]
            #for row in rows:
            #    print(row)
            #    #print(row[0])
            #    #print(dir(row)) #'get', 'items', 'keys', 'values'
            #    #print(list(row.items()))
        except:
            traceback.print_exc()
            



    def insert_rows_from_json_list(self, table_name, rows_to_insert):
        """
        Load data into a table from specified JSON list.

        Args:
            table_name (str): The destination table for the row data.(dataset_name.table_name)
            rows_to_insert (list(Dict)): Row data to be inserted with keys matching the schema fields.

        Examples:
            >>> rows_json = [
                {
                    "id": "4",
                    "name": "xyz"
                },
                {
                    "id": "5",
                    "name": "qrt"
                },
                {
                    "id": "6",
                    "name": "rrr"
                }
                ]
            >>> obj.insert_rows_from_json_list('sample_dataset.testing_bigquery',rows_json)
            New rows have been added.
        """        
        try:
            table_id = table_name
    #         table_id = Table.from_string(table_name)
    #         rows_to_insert = [
    #             {u"first_name": u"Phred", u"last_name": "Doe", u"title": "Mr", u"age": 32},
    #             {u"first_name": u"Phlyntstone", u"last_name": "Doe", u"title": "Mr", u"age": 25},
    #             ]

            errors = self.client.insert_rows_json(table_id, rows_to_insert)  # Make an API request.
            if errors == []:
                print("New rows have been added.")
            else:
                print("Encountered errors while inserting rows: {}".format(errors))
        except:
            traceback.print_exc()
            



    def insert_rows_from_cloud_data(self, table_name, schema, source_dataformat, uri):
        """
        Load data into a table from Cloud Storage.

        Args:
            table_name (str): The ID of the table to which the data should be inserted.(dataset_name.table_name)
            schema([bigquery.SchemaField]) : schema of the destinatin table.
            source_dataformat(str): file format of the source data.
            uri (str): uri of the data files to be loaded.

        Examples:
            >>> table_schema = [bigquery.SchemaField("id","STRING"),bigquery.SchemaField("dept","STRING"),bigquery.SchemaField("salary","STRING")]
            >>> uri = 'gs://gdw-dev-smai-vtctrimopt-default/csv_test.csv'
            >>> obj.insert_rows_from_cloud_data('sample_dataset.testing_bigquery2', table_schema, 'csv', uri)
            Loaded 207 rows.
        """
        try:
            table_id = table_name
            if source_dataformat == 'json':
                sourceformat = bigquery.SourceFormat.NEWLINE_DELIMITED_JSON
            else:
                sourceformat = bigquery.SourceFormat.CSV
            job_config = bigquery.LoadJobConfig(
                schema=schema,
                source_format=sourceformat,
            )

            load_job = self.client.load_table_from_uri(
                                uri,
                                table_id,
                                location="US",
                                job_config=job_config,
                            )  

            load_job.result()  

            destination_table = self.client.get_table(table_id)
            print("Loaded {} rows.".format(destination_table.num_rows))
        except:
            traceback.print_exc()
            
#         table_id = Table.from_string(table_name)


    def list_tables(self, dataset_name):    
        """
        List all tables in the specified dataset.

        Args:
            dataset_name (str): The name of the dataset whose tables to list from BigQuery API.
        
        Returns:
            [str]: List of tablenames of the tables present in the dataset.

        Example:
            >>> print(obj.list_tables('auditing_dataset'))
            ['audit_lastupdatedtime_table',
            'audit_table',
            'audit_table_new',
            'audit_table_test',
            'basic_audit_table',
            'testing_bigquery']
        """
        try:
            tables = self.client.list_tables(dataset_name)  
            return [table.table_id for table in tables]
            #print("Tables contained in '{}':".format(dataset_name))
            #for table in tables:
            #    print("{}.{}.{}".format(table.project, table.dataset_name, table.table_id))
        except:
            traceback.print_exc()


    def export_dataset(self, bucket_name, blob_name,  project, dataset_name, table_name):
        """
        Extract a table into cloud storage files.
        
        Args:
            bucket_name (str): The name of the bucket to which the table should be exported.
            blob_name (str): The blob name to which table should be saved.
            dataset_name (str): The dataset containing the table to be exported.
            table_name (str): The table to be exported.

        Examples:
            >>> obj.export_dataset('gdw-dev-smai-vtctrimopt-default', 'test_export.csv',  'sample_dataset', 'testing_bigquery')
            Exported gdw-dev-smai-vtctrimopt:sample_dataset.testing_bigquery to gs://gdw-dev-smai-vtctrimopt-default/test_export.csv
        """
        try:
            destination_uri = "gs://{}/{}".format(bucket_name, blob_name)
            dataset_ref = bigquery.DatasetReference(self.project, dataset_name)
            table_ref = dataset_ref.table(table_name)

            extract_job = self.client.extract_table(table_ref,destination_uri,location="US",) 
            extract_job.result()

            print("Exported {}:{}.{} to {}".format(self.project, dataset_name, table_name, destination_uri))
        except:
            traceback.print_exc()
            



    def bigquery_output_to_pandas(self, query_string):
        """Run a query and print the result as a pandas DataFrame

        Args:
            query_string (str): The query to be executed.
        
        Returns:
            (pandas.DataFrame): Dataframe containing the query result.

        Examples:
            >>> obj.bigquery_output_to_pandas("select * from auditing_dataset.testing_bigquery where id > 1")
            >>> print(result)
               id name
            1   2  qrt
            2   3  rrr
            3   4  xyz
            4   5  qrt
        """
        try:
            # Download query results.
            #query_string = f"""select * from {table_name}""
            dataframe = (
                self.client.query(query_string)
                .result()
                .to_dataframe(create_bqstorage_client=True,))
        
            return dataframe
        except:
            traceback.print_exc()
            




#export_dataset(
#    bucket_name="your-google-cloud-bucket-name",
#    bob_name="profiles.csv",
#    project="your-project-id",
#    dataset_id="your-dataset-id",
#    table_id="profiles"
#)
#
