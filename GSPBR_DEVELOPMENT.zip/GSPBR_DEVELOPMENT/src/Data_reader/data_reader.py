#spark = SparkSession.builder \
#.master("local") \
#.appName("Word Count") \
#.config("spark.jars.packages", "com.crealytics:spark-excel_2.11:0.12.2") \
#.getOrCreate()
#=================================================================================================
##change from original
import trevni_extraction as tvni
import traceback
import sys

##change from original
def spark_native_reader(spark, format_type, filename="", **kwargs):
    """load data from a file to DataFrame

    Args:
        spark(pyspark.sql.session.SparkSession): SparkSession
        format_type(str): format of file that needs to be read 
        filename(str): path of the file that is to be read
        **header(Boolean): This option is used to read the first line of the CSV file as column names
        **inferSchema(Boolean): when set to true it automatically infers column types based on the data

    Returns:
        pyspark.sql.dataframe.DataFrame: dataframe loaded from the corresponding file

    >>> df = spark_native_reader(spark,'csv','gs://gdw-dev-smai-vtctrimopt-default/csv_test.csv',header=True)
    >>> df.show(3)
    +---+----+------+
    | id|dept|salary|
    +---+----+------+
    |  1|  10|    10|
    |  2|  15|    20|
    |  3|  25|    30|
    +---+----+------+
    """  
    try:
        df = spark.read.format(format_type)
        for k,v in kwargs.items():
            df=df.option(k,v)
        df = df.load(filename)
        return df
    except:
        traceback.print_exc()
        


def excel_reader(spark, format_type, filename="", **kwargs):
    df = spark.read.format("com.crealytics.spark.excel")
    for k,v in kwargs.items():
        df=df.option(k,v)
    df = df.load(filename)
    return df

def trevni_reader(spark, format_type, **kwargs):
    """load data from a file of trevni format to DataFrame

    Args:
        spark(pyspark.sql.session.SparkSession): SparkSession
        format_type(str): format of file that needs to be read 
        **fields (str/[str]): Provide either fields in string format 
            or list of fields in fields.
        **columnnames ([str]): Provide columns which are needed
        **query (str/[str]): Provide either query expresion
            or list of queries in query. 
        **keys(str): keys is used to extract data in tall format for "trevni2"
        **group(str): fields that are used to groupby while using "Trevnikv"

    Returns:
        pyspark.sql.dataframe.DataFrame: dataframe loaded from the corresponding file

    >>> fields = ["FID", "START_LOT_KEY", "WAFER_SCRIBE", "DESIGN_ID", "START_DATETIME"]
    >>> query = ["DESIGN_ID='Z41C'", "PROCESS_ID in ('RPP')", "fab='16'","start_datetime>'2021-09-03'", "end_datetime<'2021-09-05'"]
    >>> df_trevni = trevni_reader(spark, "trevni", fields=fields, query=query)
    >>> df_trevni.show(3)
    +-----------------+-------------+------------+---------+-------------------+
    |              FID|START_LOT_KEY|WAFER_SCRIBE|DESIGN_ID|     START_DATETIME|
    +-----------------+-------------+------------+---------+-------------------+
    |494436L:09:N01:01|      494436L|EB7CG232SEE5|     Z41C|09/04/2021 15:02:09|
    |494436L:09:N01:02|      494436L|EB7CG232SEE5|     Z41C|09/04/2021 15:02:09|
    |494436L:09:N01:03|      494436L|EB7CG232SEE5|     Z41C|09/04/2021 15:02:09|
    +-----------------+-------------+------------+---------+-------------------+
    """
    try:
        extract = tvni.DataExtractionTrevni(spark)
        if('columnnames' in kwargs.keys()):
            column_names=kwargs['columnnames']
        elif ('fields' in kwargs.keys()):
            column_names = kwargs['fields']
        else:
            print("please provide field names ")

        if('query' in kwargs.keys()):
            query=kwargs['query']
        else:
            print("please provide query field ")
        if "group" not in kwargs.keys():
            kwargs["group"] = ''
        if "keys" not in kwargs.keys():
            kwargs["keys"] = ''
        df = extract.trevni_output(column_names, query,format_type,kwargs["group"],kwargs["keys"])
        return df
    except:
        traceback.print_exc()
        print("Error extracting from trevni")
        


def bigquery_reader(spark, format_type, tablename="", **kwargs):
    """load data from a bigquery table to DataFrame

    Args:
        spark(pyspark.sql.session.SparkSession): SparkSession
        format_type(str): format of file that needs to be read 
        tablename(str): Name of the table that needs to be read

    Returns:
        pyspark.sql.dataframe.DataFrame: dataframe loaded from the corresponding file

    >>> df = bigquery_reader(spark,'bigquery',tablename="gdw-dev-smai-vtctrimopt.auditing_dataset.audit_table")
    >>> df.show(2)
    +---+---------+----------+-------------------+-------------------+----------+------+
    | ID|DESIGN_ID|PROCESS_ID|         START_DATE|           END_DATE|  PIPELINE|STATUS|
    +---+---------+----------+-------------------+-------------------+----------+------+
    |  1|         |          |2022-02-03 07:50:17|2022-02-03 07:50:17|MONITORING|FAILED|
    |  1|         |          |2022-02-03 07:33:52|2022-02-03 07:33:52|MONITORING|FAILED|
    +---+---------+----------+-------------------+-------------------+----------+------+
    """
    try:
        df = spark.read.format("bigquery").option("table",tablename)
        for k,v in kwargs.items():
            df=df.option(k,v)
        df = df.load()
        return df
    except:
        traceback.print_exc()
        print("Unable to read from Bigquery")
        


class ReaderFactory:
    @staticmethod
    def build_reader(read_type, spark, **kwargs):
        """load data from a file to DataFrame

        Args:
            read_type(str): format of file that needs to be read
            spark(pyspark.sql.session.SparkSession): SparkSession 
            **filename(str): path of the file that is to be read for "csv","parquet","orc","txt","json"
            **tablename(str): Name of the table that needs to be read if read_type =  'bigquery'
            **header(Boolean): This option is used to read the first line of the CSV file as column names
            **inferSchema(Boolean): when set to true it automatically infers column types based on the data
            **fields(str/[str]): Provide fields which are to be present in dataframe if read_type is "trevni", "trevni2". 
                Provide fields that acts as key in "Trevnikv".
            **query(str): For "trevni2" ,provide the condition as a string or json string. 
                For "trevni" and "Trevnikv" give the path of the file
            **keys(str): keys is used to extract data in tall format for "trevni2"
            **group(str): fields that are used to groupby while using "Trevnikv"

        Returns:
            pyspark.sql.dataframe.DataFrame: dataframe loaded from the corresponding file
        """
        if read_type=="bigquery":
            return bigquery_reader(spark, format_type=read_type, **kwargs)
        elif read_type in ("csv","parquet","orc","txt","json"):
            return spark_native_reader(spark, format_type=read_type, **kwargs)
        elif read_type=='excel':
            return excel_reader(spark, format_type=read_type,  **kwargs)
        elif read_type in ('trevni','trevni2','trevnikv'):
            return trevni_reader(spark, format_type=read_type,  **kwargs)
        elif read_type in ('tteq'):
            return trevni_reader(spark, format_type=read_type,  **kwargs)

def spark_reader(read_type, spark, **kwargs):
    """load data from a file of different formats("csv", "parquet", "orc", "txt", "json", "bigquery", "trevni", "trevni2", "Trevnikv") to DataFrame

    Args:
        read_type(str): format of file that needs to be read
        spark(pyspark.sql.session.SparkSession): SparkSession 
        **filename(str): path of the file that is to be read for "csv","parquet","orc","txt","json"
        **tablename(str): Name of the table that needs to be read if read_type =  'bigquery'
        **header(Boolean): This option is used to read the first line of the CSV file as column names
        **inferSchema(Boolean): when set to true it automatically infers column types based on the data
        **fields(str/[str]): Provide fields which are to be present in dataframe if read_type is "trevni", "trevni2". 
            Provide fields that acts as key in "Trevnikv".
        **query(str): For "trevni2" ,provide the condition as a string or json string. 
            For "trevni" and "Trevnikv" give the path of the file
        **keys(str): keys is used to extract data in tall format for "trevni2"
        **group(str): fields that are used to groupby while using "Trevnikv"

    Returns:
        pyspark.sql.dataframe.DataFrame: dataframe loaded from the corresponding file

    **EXAMPLES:**

    **“csv”,”parquet”,”orc”,”txt”,”json”**

    For reading a "csv","parquet","orc","txt","json" file providing read_type,spark,filename is mandatory

    >>> df = spark_reader('csv',spark,filename='gs://gdw-dev-smai-vtctrimopt-default/csv_test.csv',header=True)
    >>> df.show(3)
    +---+----+------+
    | id|dept|salary|
    +---+----+------+
    |  1|  10|    10|
    |  2|  15|    20|
    |  3|  25|    30|
    +---+----+------+

    **trevni**

    For reading a "trevni" providing read_type,spark,fields,query is mandatory where query is path of the file

    >>> df_trevni = spark_reader('trevni',spark,fields='START_LOT_KEY,WAFER_SCRIBE,FID,BIN_BIT', query="gs://gdw-prod-data-probe-16/Z42B/2021/05/13/2021-05-13_00:20:50.93-498047L.FQQP.17.00.1.trv") 
    >>> df_trevni.show(3,truncate=False)
    +-------------+------------+-----------------+-------+
    |START_LOT_KEY|WAFER_SCRIBE|FID              |BIN_BIT|
    +-------------+------------+-----------------+-------+
    |498047L      |ED1FN052SEB4|498047L:17:N01:01|eP:eP  |
    |498047L      |ED1FN052SEB4|498047L:17:N01:02|iC:iC  |
    |498047L      |ED1FN052SEB4|498047L:17:N01:03|.:.    |
    +-------------+------------+-----------------+-------+

    **trevni2**

    For reading a "trevni2" using Query with Index columns, providing read_type,spark,fields,query is mandatory

    >>> fields = ["FID", "START_LOT_KEY", "WAFER_SCRIBE", "DESIGN_ID", "START_DATETIME"]
    >>> query = "DESIGN_ID='Z41C' AND PROCESS_ID in ('RPP') AND fab='16' AND start_datetime>'2021-09-03' AND end_datetime<'2021-09-05'"
    >>> df_trevni2 = spark_reader("trevni2", spark, fields=fields, query=query)
    >>> df_trevni2.show(3)
    +-----------------+-------------+------------+---------+-------------------+
    |              FID|START_LOT_KEY|WAFER_SCRIBE|DESIGN_ID|     START_DATETIME|
    +-----------------+-------------+------------+---------+-------------------+
    |494436L:09:N01:01|      494436L|EB7CG232SEE5|     Z41C|09/04/2021 15:02:09|
    |494436L:09:N01:02|      494436L|EB7CG232SEE5|     Z41C|09/04/2021 15:02:09|
    |494436L:09:N01:03|      494436L|EB7CG232SEE5|     Z41C|09/04/2021 15:02:09|
    +-----------------+-------------+------------+---------+-------------------+

    For reading a "trevni2" using Json Filter, providing read_type,spark,fields,query is mandatory where query is json string.

    >>> fields = 'START_LOT_KEY,WAFER_SCRIBE,PROCESS_ID,FID,BIN_BIT'
    >>> query = '{"start_lots": ["536109K"]}'
    >>> df_trevni2 = spark_reader('trevni2',spark,fields=fields,query=query)
    >>> df_trevni2.show(3)
    +-------------+------------+----------+-----------------+-------+
    |START_LOT_KEY|WAFER_SCRIBE|PROCESS_ID|              FID|BIN_BIT|
    +-------------+------------+----------+-----------------+-------+
    |      536109K|EB8CK050SEC7|      FQQP|536109K:25:N01:01|    .:*|
    |      536109K|EB8CK050SEC7|      FQQP|536109K:25:N01:02|    .:*|
    |      536109K|EB8CK050SEC7|      FQQP|536109K:25:N01:03|    .:*|
    +-------------+------------+----------+-----------------+-------+

    For reading a "trevni2" using 'Keys' to extract in tall format, providing read_type,spark,fields,query,keys is mandatory.

    >>> df_trevni2 = spark_reader("trevni2",spark,fields='FID,DESIGN_ID,FAB,LOT_ID,WAFER_ID',query='{"start_lots": ["1277511"]}', keys='/RWB_SP_RO2A_PB_MARGIN_E00_SB00_WL.*/')
    >>> df_trevni2.show(3,truncate=False)
    +-----------------+---------+---+-----------+--------+------------------------------------+-----+
    |FID              |DESIGN_ID|FAB|LOT_ID     |WAFER_ID|KEY                                 |VALUE|
    +-----------------+---------+---+-----------+--------+------------------------------------+-----+
    |1277511:01:N01:01|B47R     |10 |1277511.001|7511-01 |RWB_SP_RO2A_PB_MARGIN_E00_SB00_WL180|X    |
    |1277511:01:N01:02|B47R     |10 |1277511.001|7511-01 |RWB_SP_RO2A_PB_MARGIN_E00_SB00_WL180|818  |
    |1277511:01:N01:03|B47R     |10 |1277511.001|7511-01 |RWB_SP_RO2A_PB_MARGIN_E00_SB00_WL180|839  |
    +-----------------+---------+---+-----------+--------+------------------------------------+-----+

    **Trevnikv**

    For reading a "Trevnikv" providing read_type,spark,fields,query is mandatory where query is path of the file. group is optional
    
    with group:

    >>> df_Trevnikv = spark_reader('Trevnikv',spark,group='START_LOT_KEY,WAFER_SCRIBE,FID,BIN_BIT',fields='-fbd', query="gs://gdw-prod-data-probe-16/Z42B/2021/05/13/2021-05-13_00:20:50.93-498047L.FQQP.17.00.1.trv") 
    >>> df_Trevnikv.show(3)
    +-------------+------------+-----------------+-------+-----------+-----+
    |START_LOT_KEY|WAFER_SCRIBE|              FID|BIN_BIT|        KEY|VALUE|
    +-------------+------------+-----------------+-------+-----------+-----+
    |      498047L|ED1FN052SEB4|498047L:17:N01:01|  eP:eP|FBD_AUTOSDP|    8|
    |      498047L|ED1FN052SEB4|498047L:17:N01:02|  iC:iC|FBD_AUTOSDP|    8|
    |      498047L|ED1FN052SEB4|498047L:17:N01:03|    .:.|FBD_AUTOSDP|    3|
    +-------------+------------+-----------------+-------+-----------+-----+

    without group

    >>> df_Trevnikv2 = spark_reader('Trevnikv',spark,fields = 'FID,BIN_BIT', query="gs://gdw-prod-data-probe-16/Z42B/2021/05/13/2021-05-13_00:20:50.93-498047L.FQQP.17.00.1.trv") 
    >>> df_Trevnikv2.show(3)
    +-----------------+---+-----------------+
    |              FID|KEY|            VALUE|
    +-----------------+---+-----------------+
    |498047L:17:N01:01|FID|498047L:17:N01:01|
    |498047L:17:N01:02|FID|498047L:17:N01:02|
    |498047L:17:N01:03|FID|498047L:17:N01:03|
    +-----------------+---+-----------------+

    **bigquery**

    For reading a table "bigquery" providing read_type,spark,tablename is mandatory

    >>> df = spark_reader('bigquery',spark,tablename="gdw-dev-smai-vtctrimopt.auditing_dataset.audit_table")
    >>> df.show(2)
    +---+---------+----------+-------------------+-------------------+----------+------+
    | ID|DESIGN_ID|PROCESS_ID|         START_DATE|           END_DATE|  PIPELINE|STATUS|
    +---+---------+----------+-------------------+-------------------+----------+------+
    |  1|         |          |2022-02-03 07:50:17|2022-02-03 07:50:17|MONITORING|FAILED|
    |  1|         |          |2022-02-03 07:33:52|2022-02-03 07:33:52|MONITORING|FAILED|
    +---+---------+----------+-------------------+-------------------+----------+------+
    """ 
    read_type = read_type.lower()
    df=ReaderFactory.build_reader(read_type, spark, **kwargs)
    return df


SNOWFLAKE_SOURCE_NAME = "net.snowflake.spark.snowflake"
SNOWFLAKE_OPTIONS = {
'sfURL': "micron.us-west-2.privatelink.snowflakecomputing.com",
'sfAccount':'micron.us-west-2.privatelink',
'sfUser': 'LDR_WW_MFG_APPS_P@MICRON.COM',
'sfPassword':'Oh1aWieG3ht$4462',
'sfDatabase':'PROD_WW_BEMFG_ODS',
'sfSchema':'QA_WORK_REQUEST',
'sfWarehouse':'PROD_WW_SMTS_APPS_INTERACTIVE'
}

RDSBMS_SOURCE_NAME = "DRIVER_INFO"
MYSQL_OPTIONS = {
'sfURL': "micron.us-west-2.privatelink.snowflakecomputing.com",
'sfAccount':'micron.us-west-2.privatelink',
'sfUser': 'LDR_WW_MFG_APPS_P@MICRON.COM',
'sfPassword':'Oh1aWieG3ht$4462',
'sfDatabase':'PROD_WW_BEMFG_ODS',
'sfSchema':'QA_WORK_REQUEST',
'sfWarehouse':'PROD_WW_SMTS_APPS_INTERACTIVE',
}

df = spark_reader('snowfalke',spark,SNOWFLAKE_SOURCE_NAME, **SNOWFLAKE_OPTIONS)
df = spark_reader('MYSQL_CONNECTORS',spark,RDSBMS_SOURCE_NAME, **MYSQL_OPTIONS)

