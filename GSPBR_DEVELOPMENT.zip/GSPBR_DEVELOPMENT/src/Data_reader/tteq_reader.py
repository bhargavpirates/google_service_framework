from pyspark.sql import SparkSession
from tteindex import Configurator
from tteindex import SummaryTable
from tteindex import EndETimeIndex
from pyspark.mllib.common import _java2py

def build_tteq_params(datafiles, summaries, section, format_cols):
    tteq_params = [
    "-data=" + datafiles,
    "SUMMARY_ID=" + summaries,
    "%section=" + section,
    "-format=" + ','.join(format_cols),
    "AGG_LEVEL=0"
    ]
    return tteq_params

def get_df_tteq(tteq_params, pull_section, spark, spark_context):
    java_array = spark_context._gateway.new_array(spark_context._gateway.jvm.java.lang.String, len(tteq_params))
    for i in range(len(tteq_params)):
        java_array[i] = tteq_params[i]
    cmdline_proc = spark._jvm.com.micron.pesoft.tteq.CLProcessor(java_array)
    null_manifest = spark._jvm.com.micron.pesoft.utilities.NullManifest()
    tteq_proc = spark._jvm.com.micron.pesoft.tteq.TTEQProcessor(cmdline_proc, null_manifest)
    section_class = spark._jvm.com.micron.pesoft.tteq.summary.SectionName
    if pull_section == "BAD_BLOCK":
        data_tuple = tteq_proc.process(section_class.BadBlock())
    elif pull_section == "CHAR":
        data_tuple = tteq_proc.process(section_class.Char())
    df_output = _java2py(spark, data_tuple._1())
    return df_output


def tteq_read(spark,start_dt,end_dt,step="BURN1",pull_section="BAD_BLOCK",cols=['SUMMARY_ID','DESIGN_ID','FID','REGLIST']):
    config = Configurator()
    etimeidx = EndETimeIndex(config)
    summaries = list(etimeidx.get_summaries(start_dt, end_dt, step=step).keys())
    summaryidx = SummaryTable(config)
    summaries = summaries[:5]
    out_dict = summaryidx.get_attributes(summaries, attrs=["SUMMARY_ID", "GCS_FULLPATH"])
    location = []
    for summaryid in summaries:
        try:
            location.append(out_dict[summaryid]['GCS_FULLPATH'])
        except:
            continue
    datafiles = ','.join(location)
    summaries_str = ','.join(summaries)
    tteq_params = build_tteq_params(datafiles, summaries_str, pull_section, cols)
    sparkcon =  spark.sparkContext
    df_tteq = get_df_tteq(tteq_params, pull_section, spark, sparkcon)
    return df_tteq