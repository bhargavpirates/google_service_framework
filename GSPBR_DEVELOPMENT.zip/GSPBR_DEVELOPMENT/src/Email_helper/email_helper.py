import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from email.utils import formatdate
import os
import pandas as pd
from pretty_html_table import build_table




def email_generation(sender_email, receiver_email, subject,body='',**kwargs):
    """sends email to list of receivers with or without attachment. 

    Args:
        sender_email(str): mailid of sender
        receiver_email(str/[str]): list of mailids of receiver
        subject(str): subject of the email.
        body_message(str): body of email.
        **df(pandas.core.frame.DataFrame): Provide name of DataFrame if you want to send it in the body of email.
        **df_colour(str): Colour of DataFrame
        **file_location(str): location of attachment. No need to provide if there is no attachment.
        **file_name(str): Attachment's name gets changed to this.
        **server(str): server/host
        **port(int): port number.
        **use_tls(Boolean): Put the SMTP connection in TLS (Transport Layer Security) mode if True

    >>> email_generation("sender@abc.com",["receiver1@abc.com","receiver2@abc.com"],"sample mail","Log file",file_location="Log/logfile.txt")
    sent email
    """
    try:
        if "df_colour" not in kwargs:
            kwargs["df_colour"]='blue_light'
        if "file_location" not in kwargs:
            kwargs["file_location"]=''
        if "file_name" not in kwargs:
            kwargs["file_name"]=os.path.basename(kwargs["file_location"])
        if "server" not in kwargs:
            kwargs["server"]="relay.micron.com"
        if "port" not in kwargs:
            kwargs["port"]=25
        if "use_tls" not in kwargs:
            kwargs["use_tls"]=True
        msg = MIMEMultipart()
        msg['From'] = sender_email
        receiver = receiver_email
        if(isinstance(receiver_email, list)):
            receiver_email=", ".join(receiver_email)

        msg['To'] = receiver_email
        msg['Date'] = formatdate(localtime=True)
        msg['Subject'] = subject
        if "df" in kwargs:
            dataframe_output = build_table(kwargs["df"], kwargs["df_colour"])
            body = MIMEText(body+dataframe_output, 'html')
            msg.attach(body)
        else:
            body = MIMEText(body,'html')
            msg.attach(body)           
        if kwargs["file_location"] != '':
            attachment = open(kwargs["file_location"], "rb")
            _p = MIMEBase('application', 'octet-stream')
            _p.set_payload((attachment).read())
            encoders.encode_base64(_p)
            _p.add_header('Content-Disposition', "attachment; filename= %s" % kwargs["file_name"])
            msg.attach(_p)
        smtp = smtplib.SMTP(kwargs["server"], kwargs["port"])
        if kwargs["use_tls"]:
            smtp.starttls()
        # smtp.login(username, password)
        smtp.sendmail(sender_email, receiver, msg.as_string())
        smtp.quit()
        print("sent email")
    except Exception as e:
        print("Error in send_mail function -" + str(e))

