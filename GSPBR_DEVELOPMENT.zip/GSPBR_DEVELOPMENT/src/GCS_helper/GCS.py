import os
import sys
import traceback
import google.auth
from google.cloud import storage
#from google.cloud.storage import constants, Blob
#from pprint import pprint


class gcs_bucket:

#    ''''
#    def __init__(self,run="local"):
#        if(run=='local'):
#            self.storage_client = self.gcp_auth()
#        else:
#            self.storage_client = storage.Client()
#    '''
    """
    Wrapper around storage.Client to make simpler API requests.
    
    Examples:
        >>> bucket_obj = gcs_bucket()
    """
    def __init__(self):
        self.storage_client = storage.Client()

    def gcp_auth(self):
        try:
            os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'C:\\Users\\bgeddam\\AppData\\Roaming\\gcloud\\application_default_credentials.json'
            credentials, project = google.auth.default()
            if credentials.requires_scopes:
                credentials = credentials.with_scopes(['https://www.googleapis.com/auth/devstorage.read_write'])
            client = storage.Client(credentials=credentials)
            return client
        except:
            traceback.print_exc()
            


    def create_bucket_class_location(self, bucket_name, storage_class=None, location=None):
        try:
            bucket = self.storage_client.bucket(bucket_name)
            if (storage_class): bucket.storage_class = "COLDLINE"
            new_bucket = self.storage_client.create_bucket(bucket, location="us-west1")
            print("Created bucket {} in {} with storage class {}" \
                .format(new_bucket.name, new_bucket.location, new_bucket.storage_class))
            return new_bucket
        except:
            traceback.print_exc()
            


    def list_buckets(self,gcs_suffix=None):
        """
        List all buckets in the project associated with the client.

        Args:
            gcs_suffix(bool): if true, returns bucket object with prefix 'gs://'
        
        Returns:
            [str]: List Containing names of all buckets in the project.
        
        Examples:
            >>> obj.list_buckets()
            ['artifacts.gdw-dev-smai-vtctrimopt.appspot.com',
            'cloud-ai-platform-53a8c159-8c78-4da3-aeb8-590e153767e3',
            'dataproc-staging-us-west1-409236589846-unre4ap8',
            'dataproc-temp-us-west1-409236589846-ud4gygw4',
            'dummy-vtc-trim',
            'gcf-sources-409236589846-us-central1',
            'gdw-dev-smai-vtctrimopt-configs-bucket',
            'gdw-dev-smai-vtctrimopt-dataproc-hdfs-default',
            'gdw-dev-smai-vtctrimopt-dataproc-staging',
            'gdw-dev-smai-vtctrimopt-default',
            'gdw-dev-smai-vtctrimopt-ml-default',
            'gdw-dev-smai-vtctrimopt-notebook-examples',
            'gdw-dev-smai-vtctrimopt-notebooks-bucket',
            'gdw-dev-smai-vtctrimopt-smai-vtctrimopt',
            'us-west2-gdw-dev-smai-vtctr-5610cc03-bucket',
            'us-west2-gdw-dev-smai-vtctr-d0112e7e-bucket',
            'us.artifacts.gdw-dev-smai-vtctrimopt.appspot.com']

        """
        try:
            buckets = self.storage_client.list_buckets()
            bucket_list = ["gs://" + bucket.name for bucket in buckets] if (gcs_suffix) else [bucket.name for bucket in
                                                                                            buckets]
                                                                                            
            return bucket_list
        except:
            traceback.print_exc()
            


    def get_bucket(self, bucket_name):
        """
        Return Bucket object corresponding to the given bucket name.

        Args:
            bucket_name(str): Name of the bucket which is to be retrieved.
        
        Returns:
            google.cloud.storage.bucket.Bucket: Bucket matching the name provided.
        
        Examples:
            >>> obj.get_bucket("gdw-dev-smai-vtctrimopt-default")
            <Bucket: gdw-dev-smai-vtctrimopt-default>

        """
        try:
            bucket = self.storage_client.get_bucket(bucket_name)
            return bucket
        except:
            traceback.print_exc()
            


    def delete_bucket(self, bucket_name):
        try:
            bucket = self.storage_client.get_bucket(bucket_name)
            bucket.delete()
            print("Bucket {} deleted".format(bucket.name))
        except:
            traceback.print_exc()
            


    def upload_blob(self, bucket_name, source_file_name, destination_blob_name):
        """Uploads a file from local filesystem to the specified bucket.

        Args:
            bucket_name(str): The name of the bucket to which the blob belongs.
            source_file_name(str): The path to the file which is to uploaded.
            destination_blob_name(str): The name of the blob to be instantiated.
        
        Examples:
            >>> obj.upload_blob("gdw-dev-smai-vtctrimopt-default", "test_proj/dummy.py", "fmwk_testing/dummy")
            File test_proj/dummy.py uploaded to fmwk_testing/dummy.

        """
        try:
            bucket = self.storage_client.bucket(bucket_name)
            blob = bucket.blob(destination_blob_name)
            blob.upload_from_filename(source_file_name)
            print("File {} uploaded to {}.".format(source_file_name, destination_blob_name))
        except:
            traceback.print_exc()
            


    def download_blob(self, bucket_name, source_blob_name, destination_file_name):
        """
        Downloads a blob from the bucket to local filesystem.

        Args:
            bucket_name(str): The name of the bucket to which the blob belongs.
            source_blob_name(str): The name of the blob whose contents are to retrieved.
            destination_file_name(str): The path to which the contents should be saved.
        
        Examples:
            >>> obj.download_blob("gdw-dev-smai-vtctrimopt-default", "fmwk_testing/dummy", "dummy_dwnld.py")
            Downloaded storage object fmwk_testing/dummy from bucket gdw-dev-smai-vtctrimopt-default to local file dummy_dwnld.py.

        """
        try:
            bucket = self.storage_client.bucket(bucket_name)
            blob = bucket.blob(source_blob_name)
            blob.download_to_filename(destination_file_name)
            print("Downloaded storage object {} from bucket {} to local file {}.".format(source_blob_name, bucket_name,destination_file_name))
        except:
            traceback.print_exc()
            


    def multi_upload_blob(self, bucket_name, sourcepath, source_filenamelist, destination_path):
        """
        Uploads a list of files to the bucket.

        Args:
            bucket_name(str): The name of the bucket to which the blob should be uploaded to.
            sourcepath(str): The full path of the directory which contains the source files.
            source_filenamelist([str]): The list of filenames to be uploaded.
            destination_path(str): The name of the blobs instantiated will be destination_path + individual file name.
        
        Examples:
            >>> upload_list = ["ttr_metric.py", "dummy.py", "monitoring_main.py"]
            >>> obj.multi_upload_blob("gdw-dev-smai-vtctrimopt-default", "test_proj", upload_list, "fmwk_testing/")
            File ttr_metric.py uploaded to fmwk_testing/ttr_metric.py.
            File dummy.py uploaded to fmwk_testing/dummy.py.
            File monitoring_main.py uploaded to fmwk_testing/monitoring_main.py.
        """
        try:
            bucket = self.storage_client.bucket(bucket_name)
            for source_file_name in source_filenamelist:
                destination_blob_name = destination_path + source_file_name
                blob = bucket.blob(destination_blob_name)
                blob.upload_from_filename(sourcepath+"\\"+source_file_name)
                print("File {} uploaded to {}.".format(source_file_name, destination_blob_name))
        except:
            traceback.print_exc()
            


    def multi_download_blob(self, bucket_name, source_blob_list, destination_path):
        """Downloads a list of blobs from the bucket.

        Args:
            bucket_name(str): The name of the bucket to which the blobs belong.
            source_blob_list([str]): The list containing full names of the blobs to be downloaded.
            destination_path(str): The path to directory where the files should be saved.
        
        Examples:
            >>> dwn_list = ['project_deploy_testing/build_/config_monitoring.yml',
            'project_deploy_testing/build_/deployment_file.py',
            'project_deploy_testing/build_/dies_require_lineardescent.py']
            >>> obj.multi_download_blob("gdw-dev-smai-vtctrimopt-default", dwn_list, "/home/jupyter/rahul_test/dwnld")
            Downloaded storage object project_deploy_testing/build_/config_monitoring.yml from bucket gdw-dev-smai-vtctrimopt-default to local file /home/jupyter/rahul_test/dwnld/config_monitoring.yml.
            Downloaded storage object project_deploy_testing/build_/deployment_file.py from bucket gdw-dev-smai-vtctrimopt-default to local file /home/jupyter/rahul_test/dwnld/deployment_file.py.
            Downloaded storage object project_deploy_testing/build_/dies_require_lineardescent.py from bucket gdw-dev-smai-vtctrimopt-default to local file /home/jupyter/rahul_test/dwnld/dies_require_lineardescent.py.

        """
        try:
            bucket = self.storage_client.bucket(bucket_name)
            for source_blob_name in source_blob_list:
                blob = bucket.blob(source_blob_name)
                destination_file_name = os.path.join(destination_path, os.path.split(source_blob_name)[1])
                blob.download_to_filename(destination_file_name)
                print("Downloaded storage object {} from bucket {} to local file {}.".format(source_blob_name, bucket_name,
                                                                                        destination_file_name))
        except:
            traceback.print_exc()
            


    def list_blobs(self, bucket_name):
        """
        Lists all the blobs in the bucket.

        Args:
            bucket_name(str): Name of the bucket whose blobs are to be listed.
        
        Returns:
            [str]: List of names of all the blobs in the given bucket.
        
        Examples:
            >>> blob_list = obj.list_blobs("gdw-dev-smai-vtctrimopt-default")
            ['.ipynb_checkpoints/Untitled7.ipynb/checkpoint',
            '.ipynb_checkpoints/Untitled8.ipynb/checkpoint',
            '.ipynb_checkpoints/Untitled9.ipynb/checkpoint',
            '.ipynb_checkpoints/avro_write.ipynb/checkpoint',
            '.ipynb_checkpoints/data_extraction.ipynb/checkpoint',
            '.ipynb_checkpoints/dataextract_7days.ipynb/checkpoint',
            '.ipynb_checkpoints/dataextraction_modelpreprocessing_working.ipynb/checkpoint',
            '.ipynb_checkpoints/dataextraction_modelprerocessing.ipynb/checkpoint',
            '.ipynb_checkpoints/dataextraction_training.ipynb/checkpoint'
            ...
            ...]

        """
        try:
            blobs = self.storage_client.list_blobs(bucket_name)
            blob_list=[blob.name for blob in blobs]
            #for blob in blobs:
            #    print(blob.name)
            #if verbose:
            #    pprint(blob_list)
            return blob_list
        except:
            traceback.print_exc()
            


    def list_blobs_with_prefix(self, bucket_name, prefix, delimiter=None):
        """
        List all the blobs in the given bucket with the given prefix.

        Args:
            bucket_name(str): Name of the bucket whose blobs are to be listed.
            prefix(str): Used to filter the blobs listed; List only the blobs that start with this prefix.
            delimiter(str): If delimiter is not specified , the method returns the entire tree under the prefix.
                If specified as "/", the method prints all the subdirectories under the prefix and returns only the files directly under prefix.
                Delimiter can also be used to print out the blobs that end with certain extension.
        
        Returns:
            [str] :List of names of resulting blobs.

        Examples:
            >>> obj.list_blobs_with_prefix("gdw-dev-smai-vtctrimopt-default", "project_deploy_testing/")
            ['project_deploy_testing/dist/config_monitoring.yml',
            'project_deploy_testing/dist/deployment_file.py',
            'project_deploy_testing/dist/dies_require_lineardescent.py',
            'project_deploy_testing/dist/dummy.py',
            'project_deploy_testing/dist/least_rank_cost.py',
            'project_deploy_testing/dist/monitoring_main.py',
            'project_deploy_testing/dist/most_frequent_trim_knobs.py',
            'project_deploy_testing/dist/preprocessing_main.py',
            'project_deploy_testing/dist/preprocessing_main_latest.py',
            'project_deploy_testing/dist/repair_density.py',
            'project_deploy_testing/dist/repair_density_1.py',
            'project_deploy_testing/dist/src.zip',
            'project_deploy_testing/dist/test_monitoring.yml',
            'project_deploy_testing/dist/ttr_metric.py']

            >>> l = obj.list_blobs_with_prefix("gdw-dev-smai-vtctrimopt-default", "project_deploy_testing/", "/")
            Prefixes:
            project_deploy_testing/dist/
            project_deploy_testing/build_/
            >>> l
            ['project_deploy_testing/dummy.py',
            'project_deploy_testing/monitoring_main.py',
            'project_deploy_testing/ttr_metric.py']

        """
        #    >>> l = obj.list_blobs_with_prefix("gdw-dev-smai-vtctrimopt-default", "project_deploy_testing/", ".py")
        #    Prefixes:
        #    project_deploy_testing/build_/monitoring_main.py
        #    project_deploy_testing/build_/preprocessing_main.py
        #    project_deploy_testing/build_/repair_density_1.py
        #    project_deploy_testing/build_/preprocessing_main_latest.py
        #    project_deploy_testing/build_/deployment_file.py
        #    project_deploy_testing/build_/most_frequent_trim_knobs.py
        #    project_deploy_testing/build_/ttr_metric.py
        #    project_deploy_testing/build_/dummy.py
        #    project_deploy_testing/build_/repair_density.py
        #    project_deploy_testing/build_/least_rank_cost.py
        #    project_deploy_testing/build_/dies_require_lineardescent.py
        try:
            blobs = self.storage_client.list_blobs(bucket_name, prefix=prefix, delimiter=delimiter)
            blob_list = [blob.name for blob in blobs]
            if delimiter:
                print("Prefixes:")
                for prefix in blobs.prefixes:
                    print(prefix)
            return blob_list
        except:
            traceback.print_exc()
            


    def copy_blob(self,bucket_name, blob_name, destination_bucket_name, destination_blob_name):
        """Copies a blob from one bucket to another with a new name.

        Args:
            bucket_name(str): The name of the bucket to which the blob belongs.
            blob_name(str): The name of the blob whose contents are to be copied.
            destination_bucket_name(str): The bucket to which the blob should be copied to.
            destination_blob_name(str): The name of the copied instance of the blob.
        
        Examples:
            >>> obj.copy_blob("dummy-vtc-trim", "dum", "gdw-dev-smai-vtctrimopt-default", "fmwk_testing/copied_blob")
            Blob dum in bucket dummy-vtc-trim copied to blob fmwk_testing/copied_blob in bucket gdw-dev-smai-vtctrimopt-default.

        """
        try:
            source_bucket = self.storage_client.bucket(bucket_name)
            source_blob = source_bucket.blob(blob_name)
            destination_bucket = self.storage_client.bucket(destination_bucket_name)
            blob_copy = source_bucket.copy_blob(source_blob, destination_bucket, destination_blob_name)
            print("Blob {} in bucket {} copied to blob {} in bucket {}.".format(source_blob.name, source_bucket.name,
                                                                                blob_copy.name, destination_bucket.name, ))
        except:
            traceback.print_exc()
            


    def rename_blob(self, bucket_name, blob_name, new_name):
        """Rename the given blob.

        Args:
            bucket_name(str): The name of the bucket to which the blob belongs.
            blob_name(str): The name of the blob which is to be renamed.
            new_name(str): The new name for the blob.
        
        Examples:
            >>> obj.rename_blob("gdw-dev-smai-vtctrimopt-default", "fmwk_testing/copied_blob", "fmwk_testing/copied/dummy")
            Blob fmwk_testing/copied_blob has been renamed to fmwk_testing/copied/dummy
        """
        try:
            bucket = self.storage_client.bucket(bucket_name)
            blob = bucket.blob(blob_name)
            new_blob = bucket.rename_blob(blob, new_name)
            print("Blob {} has been renamed to {}".format(blob.name, new_blob.name))
        except:
            traceback.print_exc()
            


    def move_blob(self, bucket_name, blob_name, destination_bucket_name, destination_blob_name):
        """Moves a blob from one bucket to another with a new name.

        Args:
            bucket_name(str): The name of the bucket to which the blob belongs.
            blob_name(str): The name of the blob which is to be renamed.
            destination_bucket_name(str): The name of the bucket to which the blob should be moved.
            destination_blob_name(str): The new name for the moved blob.
        
        Examples:
            >>> storage_obj.move_blob("example-bucket", "a/example.txt", "example-destination-bucket", "b/dest_example.txt")

        """
        try:
            source_bucket = self.storage_client.bucket(bucket_name)
            source_blob = source_bucket.blob(blob_name)
            destination_bucket = self.storage_client.bucket(destination_bucket_name)
            blob_copy = source_bucket.copy_blob(source_blob, destination_bucket, destination_blob_name)
            source_bucket.delete_blob(blob_name)
            print("Blob {} in bucket {} moved to blob {} in bucket {}.".format(source_blob.name, source_bucket.name,
                                                                            blob_copy.name, destination_bucket.name, ))
        except:
            traceback.print_exc()
            


    def change_file_storage_class(self, bucket_name, blob_name, new_storage_class):
        """Change the default storage class of the blob through rewrite- in place.

        Args:
            bucket_name (str): The name of the bucket to which the blob belongs.
            blob_name (str): The name of the blob whose storage class is to updated.
            new_storage_class (str): The updated storage class for the blob.

        Returns:
            google.cloud.storage.blob.Blob: Blob Object corresponding to updated blob.
        
        Examples:
            >>> updated_blob = obj.change_file_storage_class("gdw-dev-smai-vtctrimopt-default", 'project_deploy_testing/build_/composed', 'NEARLINE')
            Blob project_deploy_testing/build_/composed in bucket gdw-dev-smai-vtctrimopt-default had its storage class set to NEARLINE

        """
        try:
            bucket = self.storage_client.get_bucket(bucket_name)
            blob = bucket.get_blob(blob_name)
            blob.update_storage_class(new_storage_class)
            print("Blob {} in bucket {} had its storage class set to {}".format(blob_name, bucket_name, blob.storage_class))
            return blob
        except:
            traceback.print_exc()
            


    def blob_metadata(self, bucket_name, blob_name):
        """Fetches metadata of the given blob.

        Args:
            bucket_name(str): The name of the bucket to which the blob belongs.
            blob_name(str): The name of the blob whose metadata is to be known.
        
        Returns:
            dict: py dict specifying metadata corresponding to the given blob
        
        Examples:
            >>> obj.blob_metadata("gdw-dev-smai-vtctrimopt-default", 'project_deploy_testing/build_/composed')
            {'color': 'Red', 'name': 'Test'}
        """
        try:
            storage_client = storage.Client()
            bucket = storage_client.bucket(bucket_name)
            blob = bucket.get_blob(blob_name)
            return blob.metadata
        except:
            traceback.print_exc()
            


    def set_blob_metadata(self, bucket_name, blob_name, metadata):
        """Set a blob's metadata.
        
        Args:
            bucket_name(str): The name of the bucket to which the blob belongs.
            blob_name(str): The name of the blob whose metadata changed.
        
        Examples:
            >>> obj.set_blob_metadata("gdw-dev-smai-vtctrimopt-default", 'project_deploy_testing/build_/composed', {'color': 'Red', 'name': 'Test'})
            The metadata for the blob project_deploy_testing/build_/composed is {'color': 'Red', 'name': 'Test'}
        """
        try:
            storage_client = storage.Client()
            bucket = storage_client.bucket(bucket_name)
            blob = bucket.get_blob(blob_name)
            blob.metadata = metadata
            blob.patch()
            print("The metadata for the blob {} is {}".format(blob.name, blob.metadata))
        except:
            traceback.print_exc()
            


    def compose_file(self,bucket_name, first_blob_name, second_blob_name, destination_blob_name):
        """Concatenate two source blobs into a destination blob. This is a special case of multi_compose_file function

        Args:
            bucket_name(str): The name of the bucket to which the source blobs belong.
            first_blob_name(str): The name of the first source blob.
            second_blob_name(str): The name of the second source blob.
            destination_blob_name(str): The name of the destination blob.
        
        Returns:
            google.cloud.storage.blob.Blob: blob object corresponding to the destination blob.
        
        Examples:
            >>> cmps_list = ['project_deploy_testing/build_/config_monitoring.yml',
                'project_deploy_testing/build_/deployment_file.py',
                'project_deploy_testing/build_/dies_require_lineardescent.py']
            >>> composed_blob = obj.compose_file("gdw-dev-smai-vtctrimopt-default", 'project_deploy_testing/build_/dies_require_lineardescent.py', 'project_deploy_testing/build_/dummy.py', 'project_deploy_testing/build_/composed')
            New composite object project_deploy_testing/build_/composed in the bucket gdw-dev-smai-vtctrimopt-default was created by combining project_deploy_testing/build_/dies_require_lineardescent.py and project_deploy_testing/build_/dummy.py

        """
        try:
            storage_client = storage.Client()
            bucket = storage_client.bucket(bucket_name)
            destination = bucket.blob(destination_blob_name)
            destination.content_type = "text/plain"
            # sources is a list of Blob instances, up to the max of 32 instances per request
            sources = [bucket.get_blob(first_blob_name), bucket.get_blob(second_blob_name)]
            destination.compose(sources)
            print(
                "New composite object {} in the bucket {} was created by combining {} and {}".format(destination_blob_name,
                                                                                                    bucket_name,
                                                                                                    first_blob_name,
                                                                                                    second_blob_name))
            return destination
        except:
            traceback.print_exc()
            


    def multi_compose_file(self, source_bucket_name, blob_name_list,destination_bucket_name, destination_blob_name):
        """
        Concatenate two or more source blobs into destination blob.

        Args:
            source_bucket_name(str): The name of the bucket to which the source blobs belong.
            blob_name_list([str]): List containing names of all the source blobs.
            destination_bucket_name(str): The name of the bucket at which the destination blobs should live.
            destination_blob_name(str): The name of the destination blob.
        
        Returns:
            google.cloud.storage.blob.Blob: blob object corresponding to the destination blob.
        
        Examples:
            >>> obj.multi_compose_file("gdw-dev-smai-vtctrimopt-default", cmps_list, "gdw-dev-smai-vtctrimopt-default", 'project_deploy_testing/build_/multi_composed')
            New composite object project_deploy_testing/build_/multi_composed in the bucket <Bucket: gdw-dev-smai-vtctrimopt-default> was created by combining batch_list ['project_deploy_testing/build_/config_monitoring.yml', 'project_deploy_testing/build_/deployment_file.py', 'project_deploy_testing/build_/dies_require_lineardescent.py']
        """
        try:
            source_bucket = self.storage_client.bucket(source_bucket_name)
            dest_bucket = self.storage_client.bucket(destination_bucket_name)

            for idx, batch in enumerate(self.chunks(blob_name_list, n=32)):
                destination = dest_bucket.blob(destination_blob_name + f"_{idx+1}")
                destination.content_type = "text/plain"
                # sources is a list of Blob instances, up to the max of 32 instances per request
                sources = [source_bucket.get_blob(blob_name) for blob_name in batch]
                destination.compose(sources)
                print(
                    "New composite object {} in the bucket {} was created by combining batch_list {} ".format(
                        destination_blob_name,
                        dest_bucket,
                        batch))
            return destination
        except:
            traceback.print_exc()
            


    def chunks(self, lst, n=32):
        for i in range(0, len(lst), n):
            yield lst[i:i + n]

    def delete_blob(self, bucket_name, blob_name):
        """
        Deletes a blob from the bucket.

        Args:
            bucket_name(str): The name of the bucket to which the blob belongs.
            blob_name(str): The name of the blob to be deleted.
        
        Examples:
            >>> obj.delete_blob("gdw-dev-smai-vtctrimopt-default", "project_deploy_testing/dist/deployment_file.py") 
            Blob project_deploy_testing/dist/deployment_file.py deleted.
        """
        try:
            bucket = self.storage_client.bucket(bucket_name)
            blob = bucket.blob(blob_name)
            blob.delete()
            print("Blob {} deleted.".format(blob_name))
        except:
            traceback.print_exc()
            



    def get_latest_updated_files(self, bucketname, prefix_name):
        """
        Get list of blobs along with their last modified times in the specified bucket sorted on the basis of which was updated the latest.
        
        Args:
            bucket_name(str): Name of the bucket whose blobs are to be listed.
            prefix(str): Used to filter the blobs listed; List only the blobs that start with this prefix.
        
        Returns:
            [(str,datetime.datetime)]: Sorted list consisting of tuples of blob name and its last modified time.
        
        Examples:
            >>> obj.get_latest_updated_files("gdw-dev-smai-vtctrimopt-default" , "fmwk_testing")
            [('fmwk_testing/monitoring_main.py',
            datetime.datetime(2022, 2, 23, 4, 51, 9, 241000, tzinfo=datetime.timezone.utc)),
            ('fmwk_testing/dummy.py',
            datetime.datetime(2022, 2, 23, 4, 51, 9, 42000, tzinfo=datetime.timezone.utc)),
            ('fmwk_testing/ttr_metric.py',
            datetime.datetime(2022, 2, 23, 4, 51, 8, 802000, tzinfo=datetime.timezone.utc)),
            ('fmwk_testing/copied/dummy',
            datetime.datetime(2022, 2, 23, 4, 39, 25, 970000, tzinfo=datetime.timezone.utc)),
            ('fmwk_testing/dummy',
            datetime.datetime(2022, 2, 23, 4, 25, 14, 603000, tzinfo=datetime.timezone.utc))]
        """
        try:
            list_of_files = self.list_blobs_with_prefix(bucketname, prefix=prefix_name)
            bucket = self.storage_client.bucket(bucketname)
            val = []
            for blob_name in list_of_files:
                if(blob_name!=prefix_name):
                    res = bucket.get_blob(blob_name)
                    s = res.updated
                    val.append((blob_name, s))
            sorted_lst=sorted(val, key=lambda x: x[1], reverse=True)
            return sorted_lst
        except:
            traceback.print_exc()
            
