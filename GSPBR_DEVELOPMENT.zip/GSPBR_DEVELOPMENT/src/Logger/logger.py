import logging
import sys
import traceback

from logging.handlers import TimedRotatingFileHandler


formatter = logging.Formatter("%(asctime)s — %(levelname)s — %(funcName)s:%(lineno)d — %(message)s", "%Y-%m-%d %H:%M:%S")

def get_console_handler():
    """provides handler to print log in console

    Returns:
        logging.StreamHandler: handler to print log in console
    """
    try:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        print("ch:",type(console_handler))
        return console_handler
    except:
        traceback.print_exc()
        print("Unable to get Console Handler for Logger")
        

def get_file_handler(logfile):
    """provides handler to save log file

    Returns:
        logging.handlers.TimedRotatingFileHandler: handler to save log file
    """
    try:
        file_handler = TimedRotatingFileHandler(logfile, when='midnight')
        file_handler.setFormatter(formatter)
        print("fh:",type(file_handler))
        return file_handler
    except:
        traceback.print_exc()
        print("Unable to get File Handler for Logger")
        

def get_logger(logger_name,logfile="",console_handler=True,file_handler=True):
    """get logger function

    Args:
        logger_name(str): name of the logger
        logfile(str): path of logfile 
        console_handler(Boolean): If true, returned logger contains handler that can save in log file
        file_handler(Boolean): If true, returned logger contains handler to print in console

    Returns:
        logging.Logger: provide Logger that has handler to save in log file and handler to print in console

    >>> l = get_logger('ros','./test.txt')
    """
    try:
        logger = logging.getLogger(logger_name)
        logger.setLevel(logging.DEBUG) # better to have too much log than not enough
        if console_handler:
            logger.addHandler(get_console_handler())
        if file_handler:
            logger.addHandler(get_file_handler(logfile))
        # with this pattern, it's rarely necessary to propagate the error up to parent
        logger.propagate = False
        return logger
    except:
        traceback.print_exc()
        print("Unable to get Logger")
        
